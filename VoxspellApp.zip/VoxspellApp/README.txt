To run the application:

1) go to this directory in the ternimal

2) copy&paste this command "java -jar voxspell.jar" to the command line

3) press Enter
